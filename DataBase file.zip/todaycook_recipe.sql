-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: todaycook
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recipe`
--

DROP TABLE IF EXISTS `recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipe` (
  `RecipeID` int NOT NULL,
  `FoodID` int NOT NULL,
  `Image_ID` int NOT NULL,
  `Address` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`RecipeID`),
  KEY `FoodID_idx` (`FoodID`),
  KEY `ImageID_idx` (`Image_ID`),
  CONSTRAINT `FoodID` FOREIGN KEY (`FoodID`) REFERENCES `food` (`FoodID`),
  CONSTRAINT `Image_ID` FOREIGN KEY (`Image_ID`) REFERENCES `foodimage` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipe`
--

LOCK TABLES `recipe` WRITE;
/*!40000 ALTER TABLE `recipe` DISABLE KEYS */;
INSERT INTO `recipe` VALUES (1,1,1,'https://terms.naver.com/entry.nhn?docId=1988410&cid=48164&categoryId=48207'),(2,2,2,'https://terms.naver.com/entry.nhn?docId=5695805&cid=48163&categoryId=48201'),(3,3,3,'https://terms.naver.com/entry.nhn?docId=3390177&cid=48164&categoryId=48204'),(4,4,4,'https://terms.naver.com/entry.nhn?docId=3390244&cid=48164&categoryId=48204'),(5,5,5,'https://terms.naver.com/entry.nhn?docId=1988570&cid=48163&categoryId=48201'),(6,6,6,'https://terms.naver.com/entry.nhn?docId=1988772&cid=48163&categoryId=48200'),(7,7,7,'https://terms.naver.com/entry.nhn?docId=1988117&cid=48163&categoryId=48201'),(8,8,8,'https://terms.naver.com/entry.nhn?docId=3390252&cid=48164&categoryId=48202'),(9,9,9,'https://terms.naver.com/entry.nhn?docId=1988654&cid=48162&categoryId=48198'),(10,10,10,'https://terms.naver.com/entry.nhn?docId=3390254&cid=48161&categoryId=48196'),(11,11,11,'https://terms.naver.com/entry.nhn?docId=3390195&cid=48163&categoryId=48200'),(12,12,12,'https://terms.naver.com/entry.nhn?docId=3390214&cid=48170&categoryId=48228'),(13,13,13,'https://terms.naver.com/entry.nhn?docId=3390143&cid=48169&categoryId=48221'),(14,14,14,'https://terms.naver.com/entry.nhn?docId=1988169&cid=48164&categoryId=48204'),(15,15,15,'https://terms.naver.com/entry.nhn?docId=1989411&cid=48163&categoryId=48200'),(16,16,16,'https://terms.naver.com/entry.nhn?docId=1988414&cid=48162&categoryId=48198'),(17,17,17,'https://terms.naver.com/entry.nhn?docId=3390148&cid=48164&categoryId=48205'),(18,18,18,'https://terms.naver.com/entry.nhn?docId=1988116&cid=48164&categoryId=48204'),(19,19,19,'https://terms.naver.com/entry.nhn?docId=3390227&cid=48161&categoryId=48197'),(20,20,20,'https://terms.naver.com/entry.nhn?docId=3390222&cid=48162&categoryId=48198'),(21,21,21,'https://terms.naver.com/entry.nhn?docId=1988409&cid=48164&categoryId=48206'),(22,22,22,'https://terms.naver.com/entry.nhn?docId=1988132&cid=48164&categoryId=48204'),(23,23,23,'https://terms.naver.com/entry.nhn?docId=1991394&cid=48162&categoryId=48199'),(24,24,24,'https://terms.naver.com/entry.nhn?docId=1991222&cid=48164&categoryId=48206'),(25,25,25,'https://terms.naver.com/entry.nhn?docId=1988137&cid=48164&categoryId=48206'),(26,26,26,'https://blog.naver.com/vqxdwht-r0a/221845182941'),(27,27,27,'https://terms.naver.com/entry.nhn?docId=1988347&cid=48164&categoryId=48203'),(28,28,28,'https://terms.naver.com/entry.nhn?docId=1988217&cid=48164&categoryId=48206'),(29,29,29,'https://terms.naver.com/entry.nhn?docId=1988416&cid=48164&categoryId=48204'),(30,30,30,'https://blog.naver.com/ippi1/221708899023'),(31,31,31,'https://terms.naver.com/entry.nhn?docId=1988466&cid=48162&categoryId=48198'),(32,32,32,'https://terms.naver.com/entry.nhn?docId=1988135&cid=48174&categoryId=48174'),(33,33,33,'https://blog.naver.com/596suk2/221632992305'),(34,34,34,'https://terms.naver.com/entry.nhn?docId=1988096&cid=48169&categoryId=48226'),(35,35,35,'https://terms.naver.com/entry.nhn?docId=5646011&cid=42785&categoryId=60402'),(36,36,36,'https://terms.naver.com/entry.nhn?docId=1988351&cid=48164&categoryId=48204'),(37,37,37,'https://terms.naver.com/entry.nhn?docId=1988136&cid=48162&categoryId=48198'),(38,38,38,'https://terms.naver.com/entry.nhn?docId=1988139&cid=48162&categoryId=48198'),(39,39,39,'https://terms.naver.com/entry.nhn?docId=1988124&cid=48164&categoryId=48206'),(40,40,40,'https://terms.naver.com/entry.nhn?docId=1988155&cid=48164&categoryId=48204'),(41,41,41,'https://blog.naver.com/oz_0315/221948352058'),(42,42,42,'https://terms.naver.com/entry.nhn?docId=1988270&cid=48166&categoryId=48215'),(43,43,43,'https://terms.naver.com/entry.nhn?docId=1988029&cid=48167&categoryId=48216'),(44,44,44,'https://terms.naver.com/entry.nhn?docId=1988276&cid=48167&categoryId=48218'),(45,45,45,'https://terms.naver.com/entry.nhn?docId=1992188&cid=48167&categoryId=48217'),(46,46,46,'https://terms.naver.com/entry.nhn?docId=5645991&cid=42785&categoryId=60402'),(47,47,47,'https://terms.naver.com/entry.nhn?docId=1988580&cid=48163&categoryId=48201'),(48,48,48,'https://terms.naver.com/entry.nhn?docId=1988503&cid=48166&categoryId=48215'),(49,49,49,'https://terms.naver.com/entry.nhn?docId=1988288&cid=48164&categoryId=48207'),(50,50,50,'https://terms.naver.com/entry.nhn?docId=1989627&cid=48163&categoryId=48201'),(51,51,51,'https://blog.naver.com/jsoof/221906312473'),(52,52,52,'https://terms.naver.com/entry.nhn?docId=1988413&cid=48163&categoryId=48201'),(53,53,53,'https://terms.naver.com/entry.nhn?docId=1988595&cid=48169&categoryId=48223'),(54,54,54,'https://terms.naver.com/entry.nhn?docId=1988075&cid=48169&categoryId=48223'),(55,55,55,'https://terms.naver.com/entry.nhn?docId=1991474&cid=48161&categoryId=48196'),(56,56,56,'https://terms.naver.com/entry.nhn?docId=1989726&cid=48169&categoryId=48223'),(57,57,57,'https://terms.naver.com/entry.nhn?docId=1988352&cid=48164&categoryId=48208'),(58,58,58,'https://terms.naver.com/entry.nhn?docId=1988056&cid=48169&categoryId=48224'),(59,59,59,'https://terms.naver.com/entry.nhn?docId=1988021&cid=48169&categoryId=48223'),(60,60,60,'https://terms.naver.com/entry.nhn?docId=5645784&cid=42785&categoryId=60402'),(61,61,61,'https://terms.naver.com/entry.nhn?docId=1991175&cid=48161&categoryId=48196'),(62,62,62,'https://terms.naver.com/entry.nhn?docId=1988832&cid=48169&categoryId=48221'),(63,63,63,'https://terms.naver.com/entry.nhn?docId=1992736&cid=48163&categoryId=48201'),(64,64,64,'https://terms.naver.com/entry.nhn?docId=1988122&cid=48164&categoryId=48206'),(65,65,65,'https://terms.naver.com/entry.nhn?docId=1988062&cid=48169&categoryId=48226'),(66,66,66,'https://terms.naver.com/entry.nhn?docId=1988202&cid=48162&categoryId=48198'),(67,67,67,'https://terms.naver.com/entry.nhn?docId=1989948&cid=48161&categoryId=48196'),(68,68,68,'https://terms.naver.com/entry.nhn?docId=1988090&cid=48169&categoryId=48226'),(69,69,69,'https://terms.naver.com/entry.nhn?docId=1988792&cid=48164&categoryId=48202');
/*!40000 ALTER TABLE `recipe` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-29 19:57:08
