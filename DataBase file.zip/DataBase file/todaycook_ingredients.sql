-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: todaycook
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ingredients`
--

DROP TABLE IF EXISTS `ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingredients` (
  `IngredientsID` int NOT NULL,
  `IngredientsName` varchar(80) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`IngredientsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredients`
--

LOCK TABLES `ingredients` WRITE;
/*!40000 ALTER TABLE `ingredients` DISABLE KEYS */;
INSERT INTO `ingredients` VALUES (1,'다시마물'),(2,'치즈'),(3,'배추'),(4,'돼지고기'),(5,'다시마'),(6,'고추'),(7,'생강'),(8,'고추장'),(9,'닭'),(10,'고구마'),(11,'대파'),(12,'된장'),(13,'멸치'),(14,'미역'),(15,'쇠고기'),(16,'간장'),(17,'마늘'),(18,'참기름'),(19,'햄'),(20,'다진쇠고기'),(21,'소시지'),(22,'양파'),(23,'풋고추'),(24,'상추'),(25,'소면'),(26,'애호박'),(27,'오이'),(28,'당근'),(29,'쌀'),(30,'숙주'),(31,'황기'),(32,'엿기름가루'),(33,'설탕'),(34,'잣'),(35,'황설탕'),(36,'오징어'),(37,'삼겹살'),(38,'고사리'),(39,'토란대'),(40,'표고버섯'),(41,'목이버섯'),(42,'양배추'),(43,'찹쌀가루'),(44,'소금'),(45,'칼국수면'),(46,'호박'),(47,'새우'),(48,'물엿'),(49,'달걀'),(50,'피망'),(51,'만두'),(52,'콩나물'),(53,'청경채'),(54,'갑오징어'),(55,'전복'),(56,'홍합'),(57,'생면'),(58,'중화면'),(59,'버터'),(60,'팥'),(61,'호두'),(62,'해삼'),(63,'죽순'),(64,'파프리카'),(65,'크림소스'),(66,'우유'),(67,'닭육수'),(68,'밀가루'),(69,'우스터소스'),(70,'스파게티면'),(71,'토마토페이스트'),(72,'바베큐소스'),(73,'마토페이스'),(74,'생크림'),(75,'에멘탈치즈'),(76,'그뤼에르치즈'),(77,'바게트'),(78,'레몬즙'),(79,'후추'),(80,'식초'),(81,'카레가루'),(82,'감자 '),(83,'강력분'),(84,'이스트'),(85,'꿀'),(86,'핫소스'),(87,'식빵'),(88,'양상추'),(89,'전분'),(90,'식용유'),(91,'깨'),(92,'대추'),(93,'두부'),(94,'단호박'),(95,'돈가스소스'),(96,'빵가루'),(97,'베이킹파우더'),(98,'우동면'),(99,'생선'),(100,'고추냉이'),(101,'밤'),(102,'한천가루'),(103,'장어');
/*!40000 ALTER TABLE `ingredients` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-29 19:57:08
