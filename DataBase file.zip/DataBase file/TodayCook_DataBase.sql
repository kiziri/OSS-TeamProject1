-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: todaycook
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'한식'),(2,'중식'),(3,'양식'),(4,'일식');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cook`
--

DROP TABLE IF EXISTS `cook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cook` (
  `IngredientsID` int(11) NOT NULL,
  `RecipeID` int(11) NOT NULL,
  `Taste_ID` int(11) NOT NULL,
  PRIMARY KEY (`IngredientsID`,`RecipeID`,`Taste_ID`),
  KEY `RecipeID_idx` (`RecipeID`),
  KEY `TasteID_idx` (`Taste_ID`),
  CONSTRAINT `IngredientsID` FOREIGN KEY (`IngredientsID`) REFERENCES `ingredients` (`IngredientsID`),
  CONSTRAINT `RecipeID` FOREIGN KEY (`RecipeID`) REFERENCES `recipe` (`RecipeID`),
  CONSTRAINT `Taste_ID` FOREIGN KEY (`Taste_ID`) REFERENCES `taste` (`TasteID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cook`
--

LOCK TABLES `cook` WRITE;
/*!40000 ALTER TABLE `cook` DISABLE KEYS */;
INSERT INTO `cook` VALUES (1,1,1),(2,2,3),(3,3,3),(4,4,3),(5,5,2),(6,6,2),(7,7,3),(8,8,2),(9,9,3),(10,10,3),(11,11,2),(12,12,1),(13,13,1),(14,14,3),(15,15,3),(16,16,2),(17,17,2),(18,18,3),(19,19,1),(20,20,2),(21,21,1),(22,22,3),(23,23,2),(24,24,1),(25,25,2),(26,26,1),(27,27,2),(28,28,3),(29,29,3),(30,30,2),(31,31,3),(32,32,2),(33,33,2),(34,34,1),(35,35,2),(36,36,2),(37,37,2),(38,38,3),(39,39,1),(40,40,2),(41,41,3),(42,42,1),(43,43,1),(44,44,2),(45,45,1),(46,46,3),(47,47,2),(48,48,2),(49,49,2),(50,50,2),(51,51,3),(52,52,3),(53,53,1),(54,54,1),(55,55,1),(56,56,1),(57,57,1),(58,58,1),(59,59,1),(60,60,2),(61,61,2),(62,62,1),(63,63,2),(64,64,2),(65,65,1),(66,66,3),(67,67,2),(68,68,1),(69,69,3);
/*!40000 ALTER TABLE `cook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food` (
  `FoodID` int(11) NOT NULL,
  `FoodName` varchar(80) NOT NULL,
  `FoodCal` int(11) NOT NULL,
  `ImageID` int(11) NOT NULL,
  `TasteID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  PRIMARY KEY (`FoodID`),
  KEY `ImageID_idx` (`ImageID`),
  KEY `TasteID_idx` (`TasteID`),
  KEY `CategoryID_idx` (`CategoryID`),
  CONSTRAINT `CategoryID` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`CategoryID`),
  CONSTRAINT `ImageID` FOREIGN KEY (`ImageID`) REFERENCES `foodimage` (`ImageID`),
  CONSTRAINT `TasteID` FOREIGN KEY (`TasteID`) REFERENCES `taste` (`TasteID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food`
--

LOCK TABLES `food` WRITE;
/*!40000 ALTER TABLE `food` DISABLE KEYS */;
INSERT INTO `food` VALUES (1,'계란말이',33,1,1,1),(2,'김치찌개',110,2,3,1),(3,'낙지볶음',91,3,3,1),(4,'닭갈비',148,4,3,1),(5,'된장찌개',182,5,2,1),(6,'미역국',45,6,2,1),(7,'부대찌개',87,7,3,1),(8,'불고기',169,8,2,1),(9,'비빔국수',368,9,3,1),(10,'비빔밥',153,10,3,1),(11,'삼계탕',92,11,2,1),(12,'식혜',86,12,1,1),(13,'약식',219,13,1,1),(14,'오삼불고기',220,14,3,1),(15,'육개장',450,15,3,1),(16,'잔치국수',46,16,2,1),(17,'잡채',145,17,2,1),(18,'제육볶음',286,18,3,1),(19,'팥죽',81,19,1,1),(20,'해물칼국수',69,20,2,1),(21,'고구마맛탕',245,21,1,2),(22,'고추잡채',178,22,3,2),(23,'군만두',179,23,2,2),(24,'깐쇼새우',498,24,1,2),(25,'깐풍기',229,25,2,2),(26,'꿔바로우',197,26,1,2),(27,'난자완스',168,27,2,2),(28,'라조기',199,28,3,2),(29,'마파두부',108,29,3,2),(30,'삼선짜장',136,30,2,2),(31,'삼선짬뽕',93,31,3,2),(32,'양장피',132,32,2,2),(33,'울면',430,33,2,2),(34,'월병',364,34,1,2),(35,'유린기',125,35,2,2),(36,'유산슬',85,36,2,2),(37,'짜장면',122,37,2,2),(38,'짬뽕',58,38,3,2),(39,'탕수육',228,39,1,2),(40,'팔보채',300,40,2,2),(41,'감바스',160,41,3,3),(42,'고구마수프',145,42,1,3),(43,'고구마피자',243,43,1,3),(44,'등심스테이크',194,44,2,3),(45,'라자냐',116,45,1,3),(46,'로제파스타',142,46,3,3),(47,'스튜',118,47,2,3),(48,'양송이스프',383,48,2,3),(49,'오믈렛',207,49,2,3),(50,'치즈퐁듀',608,50,2,3),(51,'칠리새우',271,51,3,3),(52,'카레라이스',134,52,3,3),(53,'크레페',158,53,1,3),(54,'크루아상',433,54,1,3),(55,'토마토 해물리조또',175,55,1,3),(56,'팬케이크',415,56,1,3),(57,'폭립',286,57,1,3),(58,'프렌치토스트',121,58,1,3),(59,'햄버거',263,59,1,3),(60,'가라아게',301,60,2,4),(61,'가츠동',200,61,2,4),(62,'경단',319,62,1,4),(63,'두부나베',63,63,2,4),(64,'등심돈가스',311,64,2,4),(65,'만주',330,65,1,4),(66,'볶음우동',128,66,3,4),(67,'스시',153,67,2,4),(68,'양갱',298,68,1,4),(69,'장어구이',288,69,3,4);
/*!40000 ALTER TABLE `food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foodimage`
--

DROP TABLE IF EXISTS `foodimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foodimage` (
  `ImageID` int(11) NOT NULL,
  `FilePath` varchar(200) NOT NULL,
  PRIMARY KEY (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foodimage`
--

LOCK TABLES `foodimage` WRITE;
/*!40000 ALTER TABLE `foodimage` DISABLE KEYS */;
INSERT INTO `foodimage` VALUES (1,'foodimages/Korean/계란말이.png'),(2,'foodimages/Korean/김치찌개.png'),(3,'foodimages/Korean/낙지볶음.png'),(4,'foodimages/Korean/닭갈비.png'),(5,'foodimages/Korean/된장찌개.png'),(6,'foodimages/Korean/미역국.png'),(7,'foodimages/Korean/부대찌개.png'),(8,'foodimages/Korean/불고기.png'),(9,'foodimages/Korean/비빔국수.png'),(10,'foodimages/Korean/비빔밥.png'),(11,'foodimages/Korean/삼계탕.png'),(12,'foodimages/Korean/식혜.png'),(13,'foodimages/Korean/약식.png'),(14,'foodimages/Korean/오삼불고기.png'),(15,'foodimages/Korean/육개장.png'),(16,'foodimages/Korean/잔치국수.png'),(17,'foodimages/Korean/잡채.png'),(18,'foodimages/Korean/제육볶음.png'),(19,'foodimages/Korean/팥죽.png'),(20,'foodimages/Korean/해물칼국수.png'),(21,'foodimages/Chinese/고구마맛탕.png'),(22,'foodimages/Chinese/고추잡채.png'),(23,'foodimages/Chinese/군만두.png'),(24,'foodimages/Chinese/깐쇼새우.png'),(25,'foodimages/Chinese/깐풍기.png'),(26,'foodimages/Chinese/꿔바로우.png'),(27,'foodimages/Chinese/난자완스.png'),(28,'foodimages/Chinese/라조기.png'),(29,'foodimages/Chinese/마파두부.png'),(30,'foodimages/Chinese/삼선짜장.png'),(31,'foodimages/Chinese/삼선짬뽕.png'),(32,'foodimages/Chinese/양장피.png'),(33,'foodimages/Chinese/울면.png'),(34,'foodimages/Chinese/월병.png'),(35,'foodimages/Chinese/유린기.png'),(36,'foodimages/Chinese/유산슬.png'),(37,'foodimages/Chinese/짜장면.png'),(38,'foodimages/Chinese/짬뽕.png'),(39,'foodimages/Chinese/탕수육.png'),(40,'foodimages/Chinese/팔보채.png'),(41,'foodimages/Western/감바스.png'),(42,'foodimages/Western/고구마수프.png'),(43,'foodimages/Western/고구마피자.png'),(44,'foodimages/Western/등심스테이크.png'),(45,'foodimages/Western/라자냐.png'),(46,'foodimages/Western/로제파스타.png'),(47,'foodimages/Western/스튜.png'),(48,'foodimages/Western/양송이스프.png'),(49,'foodimages/Western/오믈렛.png'),(50,'foodimages/Western/치즈퐁듀.png'),(51,'foodimages/Western/칠리새우.png'),(52,'foodimages/Western/카레라이스.png'),(53,'foodimages/Western/크레페.png'),(54,'foodimages/Western/크루아상.png'),(55,'foodimages/Western/토마토 해물리조또.png'),(56,'foodimages/Western/팬케이크.png'),(57,'foodimages/Western/폭립.png'),(58,'foodimages/Western/프렌치토스트.png'),(59,'foodimages/Western/햄버거.png'),(60,'foodimages/Japanese/가라아게.png'),(61,'foodimages/Japanese/가츠동.png'),(62,'foodimages/Japanese/경단.png'),(63,'foodimages/Japanese/두부나베.png'),(64,'foodimages/Japanese/등심돈가스.png'),(65,'foodimages/Japanese/만주.png'),(66,'foodimages/Japanese/볶음우동.png'),(67,'foodimages/Japanese/스시.png'),(68,'foodimages/Japanese/양갱.png'),(69,'foodimages/Japanese/장어구이.png');
/*!40000 ALTER TABLE `foodimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingredients`
--

DROP TABLE IF EXISTS `ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingredients` (
  `IngredientsID` int(11) NOT NULL,
  `IngredientsName` varchar(80) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`IngredientsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredients`
--

LOCK TABLES `ingredients` WRITE;
/*!40000 ALTER TABLE `ingredients` DISABLE KEYS */;
INSERT INTO `ingredients` VALUES (1,'다시마물'),(2,'치즈'),(3,'배추'),(4,'돼지고기'),(5,'다시마'),(6,'고추'),(7,'생강'),(8,'고추장'),(9,'닭'),(10,'고구마'),(11,'대파'),(12,'된장'),(13,'멸치'),(14,'미역'),(15,'쇠고기'),(16,'간장'),(17,'마늘'),(18,'참기름'),(19,'햄'),(20,'다진쇠고기'),(21,'소시지'),(22,'양파'),(23,'풋고추'),(24,'상추'),(25,'소면'),(26,'애호박'),(27,'오이'),(28,'당근'),(29,'쌀'),(30,'숙주'),(31,'황기'),(32,'엿기름가루'),(33,'설탕'),(34,'잣'),(35,'황설탕'),(36,'오징어'),(37,'삼겹살'),(38,'고사리'),(39,'토란대'),(40,'표고버섯'),(41,'목이버섯'),(42,'양배추'),(43,'찹쌀가루'),(44,'소금'),(45,'칼국수면'),(46,'호박'),(47,'새우'),(48,'물엿'),(49,'달걀'),(50,'피망'),(51,'만두'),(52,'콩나물'),(53,'청경채'),(54,'갑오징어'),(55,'전복'),(56,'홍합'),(57,'생면'),(58,'중화면'),(59,'버터'),(60,'팥'),(61,'호두'),(62,'해삼'),(63,'죽순'),(64,'파프리카'),(65,'크림소스'),(66,'우유'),(67,'닭육수'),(68,'밀가루'),(69,'우스터소스'),(70,'스파게티면'),(71,'토마토페이스트'),(72,'바베큐소스'),(73,'마토페이스'),(74,'생크림'),(75,'에멘탈치즈'),(76,'그뤼에르치즈'),(77,'바게트'),(78,'레몬즙'),(79,'후추'),(80,'식초'),(81,'카레가루'),(82,'감자 '),(83,'강력분'),(84,'이스트'),(85,'꿀'),(86,'핫소스'),(87,'식빵'),(88,'양상추'),(89,'전분'),(90,'식용유'),(91,'깨'),(92,'대추'),(93,'두부'),(94,'단호박'),(95,'돈가스소스'),(96,'빵가루'),(97,'베이킹파우더'),(98,'우동면'),(99,'생선'),(100,'고추냉이'),(101,'밤'),(102,'한천가루'),(103,'장어');
/*!40000 ALTER TABLE `ingredients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipe`
--

DROP TABLE IF EXISTS `recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipe` (
  `RecipeID` int(11) NOT NULL,
  `FoodID` int(11) NOT NULL,
  `Image_ID` int(11) NOT NULL,
  `Address` varchar(150) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`RecipeID`),
  KEY `FoodID_idx` (`FoodID`),
  KEY `ImageID_idx` (`Image_ID`),
  CONSTRAINT `FoodID` FOREIGN KEY (`FoodID`) REFERENCES `food` (`FoodID`),
  CONSTRAINT `Image_ID` FOREIGN KEY (`Image_ID`) REFERENCES `foodimage` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipe`
--

LOCK TABLES `recipe` WRITE;
/*!40000 ALTER TABLE `recipe` DISABLE KEYS */;
INSERT INTO `recipe` VALUES (1,1,1,'https://terms.naver.com/entry.nhn?docId=1988410&cid=48164&categoryId=48207'),(2,2,2,'https://terms.naver.com/entry.nhn?docId=5695805&cid=48163&categoryId=48201'),(3,3,3,'https://terms.naver.com/entry.nhn?docId=3390177&cid=48164&categoryId=48204'),(4,4,4,'https://terms.naver.com/entry.nhn?docId=3390244&cid=48164&categoryId=48204'),(5,5,5,'https://terms.naver.com/entry.nhn?docId=1988570&cid=48163&categoryId=48201'),(6,6,6,'https://terms.naver.com/entry.nhn?docId=1988772&cid=48163&categoryId=48200'),(7,7,7,'https://terms.naver.com/entry.nhn?docId=1988117&cid=48163&categoryId=48201'),(8,8,8,'https://terms.naver.com/entry.nhn?docId=3390252&cid=48164&categoryId=48202'),(9,9,9,'https://terms.naver.com/entry.nhn?docId=1988654&cid=48162&categoryId=48198'),(10,10,10,'https://terms.naver.com/entry.nhn?docId=3390254&cid=48161&categoryId=48196'),(11,11,11,'https://terms.naver.com/entry.nhn?docId=3390195&cid=48163&categoryId=48200'),(12,12,12,'https://terms.naver.com/entry.nhn?docId=3390214&cid=48170&categoryId=48228'),(13,13,13,'https://terms.naver.com/entry.nhn?docId=3390143&cid=48169&categoryId=48221'),(14,14,14,'https://terms.naver.com/entry.nhn?docId=1988169&cid=48164&categoryId=48204'),(15,15,15,'https://terms.naver.com/entry.nhn?docId=1989411&cid=48163&categoryId=48200'),(16,16,16,'https://terms.naver.com/entry.nhn?docId=1988414&cid=48162&categoryId=48198'),(17,17,17,'https://terms.naver.com/entry.nhn?docId=3390148&cid=48164&categoryId=48205'),(18,18,18,'https://terms.naver.com/entry.nhn?docId=1988116&cid=48164&categoryId=48204'),(19,19,19,'https://terms.naver.com/entry.nhn?docId=3390227&cid=48161&categoryId=48197'),(20,20,20,'https://terms.naver.com/entry.nhn?docId=3390222&cid=48162&categoryId=48198'),(21,21,21,'https://terms.naver.com/entry.nhn?docId=1988409&cid=48164&categoryId=48206'),(22,22,22,'https://terms.naver.com/entry.nhn?docId=1988132&cid=48164&categoryId=48204'),(23,23,23,'https://terms.naver.com/entry.nhn?docId=1991394&cid=48162&categoryId=48199'),(24,24,24,'https://terms.naver.com/entry.nhn?docId=1991222&cid=48164&categoryId=48206'),(25,25,25,'https://terms.naver.com/entry.nhn?docId=1988137&cid=48164&categoryId=48206'),(26,26,26,'https://blog.naver.com/vqxdwht-r0a/221845182941'),(27,27,27,'https://terms.naver.com/entry.nhn?docId=1988347&cid=48164&categoryId=48203'),(28,28,28,'https://terms.naver.com/entry.nhn?docId=1988217&cid=48164&categoryId=48206'),(29,29,29,'https://terms.naver.com/entry.nhn?docId=1988416&cid=48164&categoryId=48204'),(30,30,30,'https://blog.naver.com/ippi1/221708899023'),(31,31,31,'https://terms.naver.com/entry.nhn?docId=1988466&cid=48162&categoryId=48198'),(32,32,32,'https://terms.naver.com/entry.nhn?docId=1988135&cid=48174&categoryId=48174'),(33,33,33,'https://blog.naver.com/596suk2/221632992305'),(34,34,34,'https://terms.naver.com/entry.nhn?docId=1988096&cid=48169&categoryId=48226'),(35,35,35,'https://terms.naver.com/entry.nhn?docId=5646011&cid=42785&categoryId=60402'),(36,36,36,'https://terms.naver.com/entry.nhn?docId=1988351&cid=48164&categoryId=48204'),(37,37,37,'https://terms.naver.com/entry.nhn?docId=1988136&cid=48162&categoryId=48198'),(38,38,38,'https://terms.naver.com/entry.nhn?docId=1988139&cid=48162&categoryId=48198'),(39,39,39,'https://terms.naver.com/entry.nhn?docId=1988124&cid=48164&categoryId=48206'),(40,40,40,'https://terms.naver.com/entry.nhn?docId=1988155&cid=48164&categoryId=48204'),(41,41,41,'https://blog.naver.com/oz_0315/221948352058'),(42,42,42,'https://terms.naver.com/entry.nhn?docId=1988270&cid=48166&categoryId=48215'),(43,43,43,'https://terms.naver.com/entry.nhn?docId=1988029&cid=48167&categoryId=48216'),(44,44,44,'https://terms.naver.com/entry.nhn?docId=1988276&cid=48167&categoryId=48218'),(45,45,45,'https://terms.naver.com/entry.nhn?docId=1992188&cid=48167&categoryId=48217'),(46,46,46,'https://terms.naver.com/entry.nhn?docId=5645991&cid=42785&categoryId=60402'),(47,47,47,'https://terms.naver.com/entry.nhn?docId=1988580&cid=48163&categoryId=48201'),(48,48,48,'https://terms.naver.com/entry.nhn?docId=1988503&cid=48166&categoryId=48215'),(49,49,49,'https://terms.naver.com/entry.nhn?docId=1988288&cid=48164&categoryId=48207'),(50,50,50,'https://terms.naver.com/entry.nhn?docId=1989627&cid=48163&categoryId=48201'),(51,51,51,'https://blog.naver.com/jsoof/221906312473'),(52,52,52,'https://terms.naver.com/entry.nhn?docId=1988413&cid=48163&categoryId=48201'),(53,53,53,'https://terms.naver.com/entry.nhn?docId=1988595&cid=48169&categoryId=48223'),(54,54,54,'https://terms.naver.com/entry.nhn?docId=1988075&cid=48169&categoryId=48223'),(55,55,55,'https://terms.naver.com/entry.nhn?docId=1991474&cid=48161&categoryId=48196'),(56,56,56,'https://terms.naver.com/entry.nhn?docId=1989726&cid=48169&categoryId=48223'),(57,57,57,'https://terms.naver.com/entry.nhn?docId=1988352&cid=48164&categoryId=48208'),(58,58,58,'https://terms.naver.com/entry.nhn?docId=1988056&cid=48169&categoryId=48224'),(59,59,59,'https://terms.naver.com/entry.nhn?docId=1988021&cid=48169&categoryId=48223'),(60,60,60,'https://terms.naver.com/entry.nhn?docId=5645784&cid=42785&categoryId=60402'),(61,61,61,'https://terms.naver.com/entry.nhn?docId=1991175&cid=48161&categoryId=48196'),(62,62,62,'https://terms.naver.com/entry.nhn?docId=1988832&cid=48169&categoryId=48221'),(63,63,63,'https://terms.naver.com/entry.nhn?docId=1992736&cid=48163&categoryId=48201'),(64,64,64,'https://terms.naver.com/entry.nhn?docId=1988122&cid=48164&categoryId=48206'),(65,65,65,'https://terms.naver.com/entry.nhn?docId=1988062&cid=48169&categoryId=48226'),(66,66,66,'https://terms.naver.com/entry.nhn?docId=1988202&cid=48162&categoryId=48198'),(67,67,67,'https://terms.naver.com/entry.nhn?docId=1989948&cid=48161&categoryId=48196'),(68,68,68,'https://terms.naver.com/entry.nhn?docId=1988090&cid=48169&categoryId=48226'),(69,69,69,'https://terms.naver.com/entry.nhn?docId=1988792&cid=48164&categoryId=48202');
/*!40000 ALTER TABLE `recipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taste`
--

DROP TABLE IF EXISTS `taste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taste` (
  `TasteID` int(11) NOT NULL,
  `TasteName` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`TasteID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taste`
--

LOCK TABLES `taste` WRITE;
/*!40000 ALTER TABLE `taste` DISABLE KEYS */;
INSERT INTO `taste` VALUES (1,'단맛'),(2,'짠맛'),(3,'매운맛');
/*!40000 ALTER TABLE `taste` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-22  1:33:55
