-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: todaycook
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food` (
  `FoodID` int NOT NULL,
  `FoodName` varchar(80) NOT NULL,
  `FoodCal` int NOT NULL,
  `ImageID` int NOT NULL,
  `TasteID` int NOT NULL,
  `CategoryID` int NOT NULL,
  PRIMARY KEY (`FoodID`),
  KEY `ImageID_idx` (`ImageID`),
  KEY `TasteID_idx` (`TasteID`),
  KEY `CategoryID_idx` (`CategoryID`),
  CONSTRAINT `CategoryID` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`CategoryID`),
  CONSTRAINT `ImageID` FOREIGN KEY (`ImageID`) REFERENCES `foodimage` (`ImageID`),
  CONSTRAINT `TasteID` FOREIGN KEY (`TasteID`) REFERENCES `taste` (`TasteID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food`
--

LOCK TABLES `food` WRITE;
/*!40000 ALTER TABLE `food` DISABLE KEYS */;
INSERT INTO `food` VALUES (1,'계란말이',33,1,1,1),(2,'김치찌개',110,2,3,1),(3,'낙지볶음',91,3,3,1),(4,'닭갈비',148,4,3,1),(5,'된장찌개',182,5,2,1),(6,'미역국',45,6,2,1),(7,'부대찌개',87,7,3,1),(8,'불고기',169,8,2,1),(9,'비빔국수',368,9,3,1),(10,'비빔밥',153,10,3,1),(11,'삼계탕',92,11,2,1),(12,'식혜',86,12,1,1),(13,'약식',219,13,1,1),(14,'오삼불고기',220,14,3,1),(15,'육개장',450,15,3,1),(16,'잔치국수',46,16,2,1),(17,'잡채',145,17,2,1),(18,'제육볶음',286,18,3,1),(19,'팥죽',81,19,1,1),(20,'해물칼국수',69,20,2,1),(21,'고구마맛탕',245,21,1,2),(22,'고추잡채',178,22,3,2),(23,'군만두',179,23,2,2),(24,'깐쇼새우',498,24,1,2),(25,'깐풍기',229,25,2,2),(26,'꿔바로우',197,26,1,2),(27,'난자완스',168,27,2,2),(28,'라조기',199,28,3,2),(29,'마파두부',108,29,3,2),(30,'삼선짜장',136,30,2,2),(31,'삼선짬뽕',93,31,3,2),(32,'양장피',132,32,2,2),(33,'울면',430,33,2,2),(34,'월병',364,34,1,2),(35,'유린기',125,35,2,2),(36,'유산슬',85,36,2,2),(37,'짜장면',122,37,2,2),(38,'짬뽕',58,38,3,2),(39,'탕수육',228,39,1,2),(40,'팔보채',300,40,2,2),(41,'감바스',160,41,3,3),(42,'고구마수프',145,42,1,3),(43,'고구마피자',243,43,1,3),(44,'등심스테이크',194,44,2,3),(45,'라자냐',116,45,1,3),(46,'로제파스타',142,46,3,3),(47,'스튜',118,47,2,3),(48,'양송이스프',383,48,2,3),(49,'오믈렛',207,49,2,3),(50,'치즈퐁듀',608,50,2,3),(51,'칠리새우',271,51,3,3),(52,'카레라이스',134,52,3,3),(53,'크레페',158,53,1,3),(54,'크루아상',433,54,1,3),(55,'토마토 해물리조또',175,55,1,3),(56,'팬케이크',415,56,1,3),(57,'폭립',286,57,1,3),(58,'프렌치토스트',121,58,1,3),(59,'햄버거',263,59,1,3),(60,'가라아게',301,60,2,4),(61,'가츠동',200,61,2,4),(62,'경단',319,62,1,4),(63,'두부나베',63,63,2,4),(64,'등심돈가스',311,64,2,4),(65,'만주',330,65,1,4),(66,'볶음우동',128,66,3,4),(67,'스시',153,67,2,4),(68,'양갱',298,68,1,4),(69,'장어구이',288,69,3,4);
/*!40000 ALTER TABLE `food` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-29 19:57:08
