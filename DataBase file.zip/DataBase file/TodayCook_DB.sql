-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: todaycook
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'한식'),(2,'중식'),(3,'양식'),(4,'일식');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cook`
--

DROP TABLE IF EXISTS `cook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cook` (
  `IngredientsID` int(11) NOT NULL,
  `RecipeID` int(11) NOT NULL,
  `Taste_ID` int(11) NOT NULL,
  PRIMARY KEY (`IngredientsID`,`RecipeID`,`Taste_ID`),
  KEY `RecipeID_idx` (`RecipeID`),
  KEY `TasteID_idx` (`Taste_ID`),
  CONSTRAINT `IngredientsID` FOREIGN KEY (`IngredientsID`) REFERENCES `ingredients` (`IngredientsID`),
  CONSTRAINT `RecipeID` FOREIGN KEY (`RecipeID`) REFERENCES `recipe` (`RecipeID`),
  CONSTRAINT `Taste_ID` FOREIGN KEY (`Taste_ID`) REFERENCES `taste` (`TasteID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cook`
--

LOCK TABLES `cook` WRITE;
/*!40000 ALTER TABLE `cook` DISABLE KEYS */;
INSERT INTO `cook` VALUES (1,1,1),(2,1,1),(49,1,1),(90,1,1),(3,2,3),(4,2,3),(5,2,3),(6,2,3),(11,2,3),(6,3,3),(7,3,3),(8,3,3),(22,3,3),(8,4,3),(9,4,3),(10,4,3),(11,4,3),(42,4,3),(11,5,2),(12,5,2),(13,5,2),(82,5,2),(94,5,2),(14,6,2),(15,6,2),(16,6,2),(17,6,2),(18,6,2),(11,7,3),(19,7,3),(20,7,3),(21,7,3),(22,7,3),(11,8,2),(22,8,2),(23,8,2),(24,8,2),(22,9,3),(25,9,3),(26,9,3),(27,9,3),(28,9,3),(8,10,3),(27,10,3),(28,10,3),(29,10,3),(9,11,2),(29,11,2),(31,11,2),(92,11,2),(29,12,1),(32,12,1),(33,12,1),(34,12,1),(9,13,1),(11,13,1),(15,13,1),(30,13,1),(38,13,1),(6,14,3),(7,14,3),(17,14,3),(36,14,3),(37,14,3),(9,15,3),(11,15,3),(15,15,3),(30,15,3),(38,15,3),(3,16,2),(11,16,2),(13,16,2),(25,16,2),(49,16,2),(27,17,2),(40,17,2),(41,17,2),(4,18,3),(6,18,3),(11,18,3),(28,18,3),(42,18,3),(29,19,1),(43,19,1),(44,19,1),(60,19,1),(13,20,2),(45,20,2),(47,20,1),(82,20,2),(10,21,1),(33,21,1),(48,21,1),(90,21,1),(4,22,3),(22,22,3),(40,22,3),(49,22,3),(50,22,3),(3,23,2),(27,23,2),(28,23,2),(51,23,2),(52,23,2),(7,24,1),(22,24,1),(28,24,1),(47,24,1),(49,24,1),(7,25,2),(8,25,2),(9,25,2),(11,25,2),(17,25,2),(4,26,1),(7,26,1),(29,26,1),(82,26,1),(4,27,2),(11,27,2),(40,27,2),(53,27,2),(63,27,2),(6,28,3),(9,28,3),(40,28,3),(53,28,3),(63,28,3),(4,29,3),(6,29,3),(11,29,3),(17,29,3),(93,29,3),(4,30,2),(22,30,2),(47,30,2),(54,30,2),(58,30,2),(36,31,3),(47,31,3),(55,31,3),(56,31,3),(57,31,3),(4,32,2),(27,32,2),(28,32,2),(47,32,2),(58,32,2),(11,33,2),(28,33,2),(36,33,2),(47,33,2),(58,33,2),(33,34,1),(49,34,1),(59,34,1),(60,34,1),(61,34,1),(3,35,2),(11,35,2),(49,35,2),(66,35,2),(4,36,2),(40,36,2),(47,36,2),(62,36,2),(63,36,2),(4,37,2),(11,37,2),(22,37,2),(57,37,2),(4,38,3),(36,38,3),(47,38,3),(57,38,3),(63,38,3),(4,39,1),(27,39,1),(41,39,1),(49,39,1),(82,39,1),(36,40,2),(41,40,2),(47,40,2),(63,40,2),(4,41,3),(47,41,3),(64,41,3),(10,42,1),(59,42,1),(65,42,1),(66,42,1),(67,42,1),(10,43,1),(19,43,1),(68,43,1),(71,43,1),(75,43,1),(22,44,2),(64,44,2),(69,44,2),(82,44,2),(2,45,1),(15,45,1),(50,45,1),(6,46,3),(17,46,3),(47,46,3),(70,46,3),(15,47,2),(64,47,2),(71,47,2),(72,47,2),(4,48,2),(17,48,2),(65,48,2),(44,49,2),(49,49,2),(59,49,2),(74,49,2),(11,50,2),(75,50,2),(76,50,2),(77,50,2),(78,50,2),(6,51,3),(17,51,3),(47,51,3),(79,51,3),(80,51,3),(28,52,3),(72,52,3),(81,52,3),(82,52,3),(49,53,1),(59,53,1),(66,53,1),(68,53,1),(49,54,1),(59,54,1),(66,54,1),(83,54,1),(84,54,1),(22,55,1),(29,55,1),(36,55,1),(47,55,1),(56,55,1),(33,56,1),(49,56,1),(66,56,1),(68,56,1),(85,56,1),(4,57,1),(7,57,1),(17,57,1),(72,57,1),(86,57,1),(33,58,1),(49,58,1),(59,58,1),(66,58,1),(87,58,1),(4,59,1),(22,59,1),(88,59,1),(66,60,2),(89,60,2),(90,60,2),(4,61,2),(23,61,2),(29,61,2),(49,61,2),(68,61,2),(33,62,1),(38,62,1),(43,62,1),(44,62,1),(91,62,1),(3,63,2),(16,63,2),(68,63,2),(93,63,2),(4,64,2),(44,64,2),(49,64,2),(95,64,2),(96,64,2),(33,65,1),(49,65,1),(60,65,1),(68,65,1),(97,65,1),(8,66,3),(22,66,3),(48,66,3),(98,66,3),(29,67,2),(33,67,2),(80,67,2),(99,67,2),(100,67,2),(33,68,1),(48,68,1),(60,68,1),(101,68,1),(102,68,1),(16,69,3),(33,69,3),(88,69,3),(103,69,3);
/*!40000 ALTER TABLE `cook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food` (
  `FoodID` int(11) NOT NULL,
  `FoodName` varchar(80) NOT NULL,
  `FoodCal` int(11) NOT NULL,
  `ImageID` int(11) NOT NULL,
  `TasteID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  PRIMARY KEY (`FoodID`),
  KEY `ImageID_idx` (`ImageID`),
  KEY `TasteID_idx` (`TasteID`),
  KEY `CategoryID_idx` (`CategoryID`),
  CONSTRAINT `CategoryID` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`CategoryID`),
  CONSTRAINT `ImageID` FOREIGN KEY (`ImageID`) REFERENCES `foodimage` (`ImageID`),
  CONSTRAINT `TasteID` FOREIGN KEY (`TasteID`) REFERENCES `taste` (`TasteID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food`
--

LOCK TABLES `food` WRITE;
/*!40000 ALTER TABLE `food` DISABLE KEYS */;
INSERT INTO `food` VALUES (1,'계란말이',33,1,1,1),(2,'김치찌개',110,2,3,1),(3,'낙지볶음',91,3,3,1),(4,'닭갈비',148,4,3,1),(5,'된장찌개',182,5,2,1),(6,'미역국',45,6,2,1),(7,'부대찌개',87,7,3,1),(8,'불고기',169,8,2,1),(9,'비빔국수',368,9,3,1),(10,'비빔밥',153,10,3,1),(11,'삼계탕',92,11,2,1),(12,'식혜',86,12,1,1),(13,'약식',219,13,1,1),(14,'오삼불고기',220,14,3,1),(15,'육개장',450,15,3,1),(16,'잔치국수',46,16,2,1),(17,'잡채',145,17,2,1),(18,'제육볶음',286,18,3,1),(19,'팥죽',81,19,1,1),(20,'해물칼국수',69,20,2,1),(21,'고구마맛탕',245,21,1,2),(22,'고추잡채',178,22,3,2),(23,'군만두',179,23,2,2),(24,'깐쇼새우',498,24,1,2),(25,'깐풍기',229,25,2,2),(26,'꿔바로우',197,26,1,2),(27,'난자완스',168,27,2,2),(28,'라조기',199,28,3,2),(29,'마파두부',108,29,3,2),(30,'삼선짜장',136,30,2,2),(31,'삼선짬뽕',93,31,3,2),(32,'양장피',132,32,2,2),(33,'울면',430,33,2,2),(34,'월병',364,34,1,2),(35,'유린기',125,35,2,2),(36,'유산슬',85,36,2,2),(37,'짜장면',122,37,2,2),(38,'짬뽕',58,38,3,2),(39,'탕수육',228,39,1,2),(40,'팔보채',300,40,2,2),(41,'감바스',160,41,3,3),(42,'고구마수프',145,42,1,3),(43,'고구마피자',243,43,1,3),(44,'등심스테이크',194,44,2,3),(45,'라자냐',116,45,1,3),(46,'로제파스타',142,46,3,3),(47,'스튜',118,47,2,3),(48,'양송이스프',383,48,2,3),(49,'오믈렛',207,49,2,3),(50,'치즈퐁듀',608,50,2,3),(51,'칠리새우',271,51,3,3),(52,'카레라이스',134,52,3,3),(53,'크레페',158,53,1,3),(54,'크루아상',433,54,1,3),(55,'토마토 해물리조또',175,55,1,3),(56,'팬케이크',415,56,1,3),(57,'폭립',286,57,1,3),(58,'프렌치토스트',121,58,1,3),(59,'햄버거',263,59,1,3),(60,'가라아게',301,60,2,4),(61,'가츠동',200,61,2,4),(62,'경단',319,62,1,4),(63,'두부나베',63,63,2,4),(64,'등심돈가스',311,64,2,4),(65,'만주',330,65,1,4),(66,'볶음우동',128,66,3,4),(67,'스시',153,67,2,4),(68,'양갱',298,68,1,4),(69,'장어구이',288,69,3,4);
/*!40000 ALTER TABLE `food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foodimage`
--

DROP TABLE IF EXISTS `foodimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foodimage` (
  `ImageID` int(11) NOT NULL,
  `FilePath` varchar(200) NOT NULL,
  PRIMARY KEY (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foodimage`
--

LOCK TABLES `foodimage` WRITE;
/*!40000 ALTER TABLE `foodimage` DISABLE KEYS */;
INSERT INTO `foodimage` VALUES (1,'foodimages/Korean/eggroll.png'),(2,'foodimages/Korean/Kimchijjigaei.png'),(3,'foodimages/Korean/nakjibokkeum.png'),(4,'foodimages/Korean/Dakgalbi,.png'),(5,'foodimages/Korean/doenjangjjigae.png'),(6,'foodimages/Korean/Miyeokguk.png'),(7,'foodimages/Korean/budaejjigae.png'),(8,'foodimages/Korean/Bulgogi.png'),(9,'foodimages/Korean/Bibimguksu.png'),(10,'foodimages/Korean/Bibimbap.png'),(11,'foodimages/Korean/samgyetang.png'),(12,'foodimages/Korean/Sikhye.png'),(13,'foodimages/Korean/Yaksik.png'),(14,'foodimages/Korean/SquidandPorkBellyBulgogi.png'),(15,'foodimages/Korean/Yukgaejang.png'),(16,'foodimages/Korean/Janchiguksu.png'),(17,'foodimages/Korean/Japchae.png'),(18,'foodimages/Korean/jeyukbokkeum.png'),(19,'foodimages/Korean/Patjuk.png'),(20,'foodimages/Korean/Haemulkalguksu.png'),(21,'foodimages/Chinese/Gogumamattang.png'),(22,'foodimages/Chinese/pepperjapchae.png'),(23,'foodimages/Chinese/Gunmandu.png'),(24,'foodimages/Chinese/ShrimpwithChiliSauce.png'),(25,'foodimages/Chinese/kkanpunggi.png'),(26,'foodimages/Chinese/DoubleCookedPorkSlices.png'),(27,'foodimages/Chinese/Eggcell.png'),(28,'foodimages/Chinese/Lazogi.png'),(29,'foodimages/Chinese/Mapotofu.png'),(30,'foodimages/Chinese/SamsunJjajang.png'),(31,'foodimages/Chinese/SamsunChampon.png'),(32,'foodimages/Chinese/yangjangpi.png'),(33,'foodimages/Chinese/ulmyeon.png'),(34,'foodimages/Chinese/wolbyeong.png'),(35,'foodimages/Chinese/yulingi.png'),(36,'foodimages/Chinese/yusanseul.png'),(37,'foodimages/Chinese/jjajangmyeon.png'),(38,'foodimages/Chinese/jjamppong.png'),(39,'foodimages/Chinese/tangsuyug.png'),(40,'foodimages/Chinese/palbochae.png'),(41,'foodimages/Western/gambaseu.png'),(42,'foodimages/Western/gogumasupeu.png'),(43,'foodimages/Western/Sweetpotatopizza.png'),(44,'foodimages/Western/Sirloinsteak.png'),(45,'foodimages/Western/Lasagna.png'),(46,'foodimages/Western/RosePasta.png'),(47,'foodimages/Western/stew.png'),(48,'foodimages/Western/YangsongSoup.png'),(49,'foodimages/Western/omelet.png'),(50,'foodimages/Western/Cheesefondue.png'),(51,'foodimages/Western/Chilishrimp.png'),(52,'foodimages/Western/Curryrice.png'),(53,'foodimages/Western/Crepe.png'),(54,'foodimages/Western/Croissant.png'),(55,'foodimages/Western/TomatoSeafoodRisotto.png'),(56,'foodimages/Western/pancake.png'),(57,'foodimages/Western/poglib.png'),(58,'foodimages/Western/Frenchtoast.png'),(59,'foodimages/Western/hamburger.png'),(60,'foodimages/Japanese/Karaage.png'),(61,'foodimages/Japanese/Katsudong.png'),(62,'foodimages/Japanese/gyeongdan.png'),(63,'foodimages/Japanese/Tofunabe.png'),(64,'foodimages/Japanese/Sirloincutlet.png'),(65,'foodimages/Japanese/Manju.png'),(66,'foodimages/Japanese/Stirfriedudon .png'),(67,'foodimages/Japanese/sushi.png'),(68,'foodimages/Japanese/yanggaeng.png'),(69,'foodimages/Japanese/jangeogui.png');
/*!40000 ALTER TABLE `foodimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingredients`
--

DROP TABLE IF EXISTS `ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingredients` (
  `IngredientsID` int(11) NOT NULL,
  `IngredientsName` varchar(80) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`IngredientsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredients`
--

LOCK TABLES `ingredients` WRITE;
/*!40000 ALTER TABLE `ingredients` DISABLE KEYS */;
INSERT INTO `ingredients` VALUES (1,'다시마물'),(2,'치즈'),(3,'배추'),(4,'돼지고기'),(5,'다시마'),(6,'고추'),(7,'생강'),(8,'고추장'),(9,'닭'),(10,'고구마'),(11,'대파'),(12,'된장'),(13,'멸치'),(14,'미역'),(15,'쇠고기'),(16,'간장'),(17,'마늘'),(18,'참기름'),(19,'햄'),(20,'다진쇠고기'),(21,'소시지'),(22,'양파'),(23,'풋고추'),(24,'상추'),(25,'소면'),(26,'애호박'),(27,'오이'),(28,'당근'),(29,'쌀'),(30,'숙주'),(31,'황기'),(32,'엿기름가루'),(33,'설탕'),(34,'잣'),(35,'황설탕'),(36,'오징어'),(37,'삼겹살'),(38,'고사리'),(39,'토란대'),(40,'표고버섯'),(41,'목이버섯'),(42,'양배추'),(43,'찹쌀가루'),(44,'소금'),(45,'칼국수면'),(46,'호박'),(47,'새우'),(48,'물엿'),(49,'달걀'),(50,'피망'),(51,'만두'),(52,'콩나물'),(53,'청경채'),(54,'갑오징어'),(55,'전복'),(56,'홍합'),(57,'생면'),(58,'중화면'),(59,'버터'),(60,'팥'),(61,'호두'),(62,'해삼'),(63,'죽순'),(64,'파프리카'),(65,'크림소스'),(66,'우유'),(67,'닭육수'),(68,'밀가루'),(69,'우스터소스'),(70,'스파게티면'),(71,'토마토페이스트'),(72,'바베큐소스'),(73,'마토페이스'),(74,'생크림'),(75,'에멘탈치즈'),(76,'그뤼에르치즈'),(77,'바게트'),(78,'레몬즙'),(79,'후추'),(80,'식초'),(81,'카레가루'),(82,'감자 '),(83,'강력분'),(84,'이스트'),(85,'꿀'),(86,'핫소스'),(87,'식빵'),(88,'양상추'),(89,'전분'),(90,'식용유'),(91,'깨'),(92,'대추'),(93,'두부'),(94,'단호박'),(95,'돈가스소스'),(96,'빵가루'),(97,'베이킹파우더'),(98,'우동면'),(99,'생선'),(100,'고추냉이'),(101,'밤'),(102,'한천가루'),(103,'장어');
/*!40000 ALTER TABLE `ingredients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipe`
--

DROP TABLE IF EXISTS `recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipe` (
  `RecipeID` int(11) NOT NULL,
  `FoodID` int(11) NOT NULL,
  `Image_ID` int(11) NOT NULL,
  `Address` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`RecipeID`),
  KEY `FoodID_idx` (`FoodID`),
  KEY `ImageID_idx` (`Image_ID`),
  CONSTRAINT `FoodID` FOREIGN KEY (`FoodID`) REFERENCES `food` (`FoodID`),
  CONSTRAINT `Image_ID` FOREIGN KEY (`Image_ID`) REFERENCES `foodimage` (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipe`
--

LOCK TABLES `recipe` WRITE;
/*!40000 ALTER TABLE `recipe` DISABLE KEYS */;
INSERT INTO `recipe` VALUES (1,1,1,'https://terms.naver.com/entry.nhn?docId=1988410&cid=48164&categoryId=48207'),(2,2,2,'https://terms.naver.com/entry.nhn?docId=5695805&cid=48163&categoryId=48201'),(3,3,3,'https://terms.naver.com/entry.nhn?docId=3390177&cid=48164&categoryId=48204'),(4,4,4,'https://terms.naver.com/entry.nhn?docId=3390244&cid=48164&categoryId=48204'),(5,5,5,'https://terms.naver.com/entry.nhn?docId=1988570&cid=48163&categoryId=48201'),(6,6,6,'https://terms.naver.com/entry.nhn?docId=1988772&cid=48163&categoryId=48200'),(7,7,7,'https://terms.naver.com/entry.nhn?docId=1988117&cid=48163&categoryId=48201'),(8,8,8,'https://terms.naver.com/entry.nhn?docId=3390252&cid=48164&categoryId=48202'),(9,9,9,'https://terms.naver.com/entry.nhn?docId=1988654&cid=48162&categoryId=48198'),(10,10,10,'https://terms.naver.com/entry.nhn?docId=3390254&cid=48161&categoryId=48196'),(11,11,11,'https://terms.naver.com/entry.nhn?docId=3390195&cid=48163&categoryId=48200'),(12,12,12,'https://terms.naver.com/entry.nhn?docId=3390214&cid=48170&categoryId=48228'),(13,13,13,'https://terms.naver.com/entry.nhn?docId=3390143&cid=48169&categoryId=48221'),(14,14,14,'https://terms.naver.com/entry.nhn?docId=1988169&cid=48164&categoryId=48204'),(15,15,15,'https://terms.naver.com/entry.nhn?docId=1989411&cid=48163&categoryId=48200'),(16,16,16,'https://terms.naver.com/entry.nhn?docId=1988414&cid=48162&categoryId=48198'),(17,17,17,'https://terms.naver.com/entry.nhn?docId=3390148&cid=48164&categoryId=48205'),(18,18,18,'https://terms.naver.com/entry.nhn?docId=1988116&cid=48164&categoryId=48204'),(19,19,19,'https://terms.naver.com/entry.nhn?docId=3390227&cid=48161&categoryId=48197'),(20,20,20,'https://terms.naver.com/entry.nhn?docId=3390222&cid=48162&categoryId=48198'),(21,21,21,'https://terms.naver.com/entry.nhn?docId=1988409&cid=48164&categoryId=48206'),(22,22,22,'https://terms.naver.com/entry.nhn?docId=1988132&cid=48164&categoryId=48204'),(23,23,23,'https://terms.naver.com/entry.nhn?docId=1991394&cid=48162&categoryId=48199'),(24,24,24,'https://terms.naver.com/entry.nhn?docId=1991222&cid=48164&categoryId=48206'),(25,25,25,'https://terms.naver.com/entry.nhn?docId=1988137&cid=48164&categoryId=48206'),(26,26,26,'https://blog.naver.com/vqxdwht-r0a/221845182941'),(27,27,27,'https://terms.naver.com/entry.nhn?docId=1988347&cid=48164&categoryId=48203'),(28,28,28,'https://terms.naver.com/entry.nhn?docId=1988217&cid=48164&categoryId=48206'),(29,29,29,'https://terms.naver.com/entry.nhn?docId=1988416&cid=48164&categoryId=48204'),(30,30,30,'https://blog.naver.com/ippi1/221708899023'),(31,31,31,'https://terms.naver.com/entry.nhn?docId=1988466&cid=48162&categoryId=48198'),(32,32,32,'https://terms.naver.com/entry.nhn?docId=1988135&cid=48174&categoryId=48174'),(33,33,33,'https://blog.naver.com/596suk2/221632992305'),(34,34,34,'https://terms.naver.com/entry.nhn?docId=1988096&cid=48169&categoryId=48226'),(35,35,35,'https://terms.naver.com/entry.nhn?docId=5646011&cid=42785&categoryId=60402'),(36,36,36,'https://terms.naver.com/entry.nhn?docId=1988351&cid=48164&categoryId=48204'),(37,37,37,'https://terms.naver.com/entry.nhn?docId=1988136&cid=48162&categoryId=48198'),(38,38,38,'https://terms.naver.com/entry.nhn?docId=1988139&cid=48162&categoryId=48198'),(39,39,39,'https://terms.naver.com/entry.nhn?docId=1988124&cid=48164&categoryId=48206'),(40,40,40,'https://terms.naver.com/entry.nhn?docId=1988155&cid=48164&categoryId=48204'),(41,41,41,'https://blog.naver.com/oz_0315/221948352058'),(42,42,42,'https://terms.naver.com/entry.nhn?docId=1988270&cid=48166&categoryId=48215'),(43,43,43,'https://terms.naver.com/entry.nhn?docId=1988029&cid=48167&categoryId=48216'),(44,44,44,'https://terms.naver.com/entry.nhn?docId=1988276&cid=48167&categoryId=48218'),(45,45,45,'https://terms.naver.com/entry.nhn?docId=1992188&cid=48167&categoryId=48217'),(46,46,46,'https://terms.naver.com/entry.nhn?docId=5645991&cid=42785&categoryId=60402'),(47,47,47,'https://terms.naver.com/entry.nhn?docId=1988580&cid=48163&categoryId=48201'),(48,48,48,'https://terms.naver.com/entry.nhn?docId=1988503&cid=48166&categoryId=48215'),(49,49,49,'https://terms.naver.com/entry.nhn?docId=1988288&cid=48164&categoryId=48207'),(50,50,50,'https://terms.naver.com/entry.nhn?docId=1989627&cid=48163&categoryId=48201'),(51,51,51,'https://blog.naver.com/jsoof/221906312473'),(52,52,52,'https://terms.naver.com/entry.nhn?docId=1988413&cid=48163&categoryId=48201'),(53,53,53,'https://terms.naver.com/entry.nhn?docId=1988595&cid=48169&categoryId=48223'),(54,54,54,'https://terms.naver.com/entry.nhn?docId=1988075&cid=48169&categoryId=48223'),(55,55,55,'https://terms.naver.com/entry.nhn?docId=1991474&cid=48161&categoryId=48196'),(56,56,56,'https://terms.naver.com/entry.nhn?docId=1989726&cid=48169&categoryId=48223'),(57,57,57,'https://terms.naver.com/entry.nhn?docId=1988352&cid=48164&categoryId=48208'),(58,58,58,'https://terms.naver.com/entry.nhn?docId=1988056&cid=48169&categoryId=48224'),(59,59,59,'https://terms.naver.com/entry.nhn?docId=1988021&cid=48169&categoryId=48223'),(60,60,60,'https://terms.naver.com/entry.nhn?docId=5645784&cid=42785&categoryId=60402'),(61,61,61,'https://terms.naver.com/entry.nhn?docId=1991175&cid=48161&categoryId=48196'),(62,62,62,'https://terms.naver.com/entry.nhn?docId=1988832&cid=48169&categoryId=48221'),(63,63,63,'https://terms.naver.com/entry.nhn?docId=1992736&cid=48163&categoryId=48201'),(64,64,64,'https://terms.naver.com/entry.nhn?docId=1988122&cid=48164&categoryId=48206'),(65,65,65,'https://terms.naver.com/entry.nhn?docId=1988062&cid=48169&categoryId=48226'),(66,66,66,'https://terms.naver.com/entry.nhn?docId=1988202&cid=48162&categoryId=48198'),(67,67,67,'https://terms.naver.com/entry.nhn?docId=1989948&cid=48161&categoryId=48196'),(68,68,68,'https://terms.naver.com/entry.nhn?docId=1988090&cid=48169&categoryId=48226'),(69,69,69,'https://terms.naver.com/entry.nhn?docId=1988792&cid=48164&categoryId=48202');
/*!40000 ALTER TABLE `recipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taste`
--

DROP TABLE IF EXISTS `taste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taste` (
  `TasteID` int(11) NOT NULL,
  `TasteName` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`TasteID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taste`
--

LOCK TABLES `taste` WRITE;
/*!40000 ALTER TABLE `taste` DISABLE KEYS */;
INSERT INTO `taste` VALUES (1,'단맛'),(2,'짠맛'),(3,'매운맛');
/*!40000 ALTER TABLE `taste` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-30  1:40:38
