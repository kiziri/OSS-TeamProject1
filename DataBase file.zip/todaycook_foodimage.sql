-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: todaycook
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `foodimage`
--

DROP TABLE IF EXISTS `foodimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foodimage` (
  `ImageID` int NOT NULL,
  `FilePath` varchar(200) NOT NULL,
  PRIMARY KEY (`ImageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foodimage`
--

LOCK TABLES `foodimage` WRITE;
/*!40000 ALTER TABLE `foodimage` DISABLE KEYS */;
INSERT INTO `foodimage` VALUES (1,'foodimages/Korean/eggroll.png'),(2,'foodimages/Korean/Kimchijjigaei.png'),(3,'foodimages/Korean/nakjibokkeum.png'),(4,'foodimages/Korean/Dakgalbi,.png'),(5,'foodimages/Korean/doenjangjjigae.png'),(6,'foodimages/Korean/Miyeokguk.png'),(7,'foodimages/Korean/budaejjigae.png'),(8,'foodimages/Korean/Bulgogi.png'),(9,'foodimages/Korean/Bibimguksu.png'),(10,'foodimages/Korean/Bibimbap.png'),(11,'foodimages/Korean/samgyetang.png'),(12,'foodimages/Korean/Sikhye.png'),(13,'foodimages/Korean/Yaksik.png'),(14,'foodimages/Korean/SquidandPorkBellyBulgogi.png'),(15,'foodimages/Korean/Yukgaejang.png'),(16,'foodimages/Korean/Janchiguksu.png'),(17,'foodimages/Korean/Japchae.png'),(18,'foodimages/Korean/jeyukbokkeum.png'),(19,'foodimages/Korean/Patjuk.png'),(20,'foodimages/Korean/Haemulkalguksu.png'),(21,'foodimages/Chinese/Gogumamattang.png'),(22,'foodimages/Chinese/pepperjapchae.png'),(23,'foodimages/Chinese/Gunmandu.png'),(24,'foodimages/Chinese/ShrimpwithChiliSauce.png'),(25,'foodimages/Chinese/kkanpunggi.png'),(26,'foodimages/Chinese/DoubleCookedPorkSlices.png'),(27,'foodimages/Chinese/Eggcell.png'),(28,'foodimages/Chinese/Lazogi.png'),(29,'foodimages/Chinese/Mapotofu.png'),(30,'foodimages/Chinese/SamsunJjajang.png'),(31,'foodimages/Chinese/SamsunChampon.png'),(32,'foodimages/Chinese/yangjangpi.png'),(33,'foodimages/Chinese/ulmyeon.png'),(34,'foodimages/Chinese/wolbyeong.png'),(35,'foodimages/Chinese/yulingi.png'),(36,'foodimages/Chinese/yusanseul.png'),(37,'foodimages/Chinese/jjajangmyeon.png'),(38,'foodimages/Chinese/jjamppong.png'),(39,'foodimages/Chinese/tangsuyug.png'),(40,'foodimages/Chinese/palbochae.png'),(41,'foodimages/Western/gambaseu.png'),(42,'foodimages/Western/gogumasupeu.png'),(43,'foodimages/Western/Sweetpotatopizza.png'),(44,'foodimages/Western/Sirloinsteak.png'),(45,'foodimages/Western/Lasagna.png'),(46,'foodimages/Western/RosePasta.png'),(47,'foodimages/Western/stew.png'),(48,'foodimages/Western/YangsongSoup.png'),(49,'foodimages/Western/omelet.png'),(50,'foodimages/Western/Cheesefondue.png'),(51,'foodimages/Western/Chilishrimp.png'),(52,'foodimages/Western/Curryrice.png'),(53,'foodimages/Western/Crepe.png'),(54,'foodimages/Western/Croissant.png'),(55,'foodimages/Western/TomatoSeafoodRisotto.png'),(56,'foodimages/Western/pancake.png'),(57,'foodimages/Western/poglib.png'),(58,'foodimages/Western/Frenchtoast.png'),(59,'foodimages/Western/hamburger.png'),(60,'foodimages/Japanese/Karaage.png'),(61,'foodimages/Japanese/Katsudong.png'),(62,'foodimages/Japanese/gyeongdan.png'),(63,'foodimages/Japanese/Tofunabe.png'),(64,'foodimages/Japanese/Sirloincutlet.png'),(65,'foodimages/Japanese/Manju.png'),(66,'foodimages/Japanese/Stirfriedudon .png'),(67,'foodimages/Japanese/sushi.png'),(68,'foodimages/Japanese/yanggaeng.png'),(69,'foodimages/Japanese/jangeogui.png');
/*!40000 ALTER TABLE `foodimage` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-29 19:57:08
